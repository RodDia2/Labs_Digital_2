/*
 * File:   lab3_main.c
 * Author: jrdia
 *
 * Created on February 8, 2021, 10:07 AM
 */


#include <xc.h>

void main(void) {
    return;
}
